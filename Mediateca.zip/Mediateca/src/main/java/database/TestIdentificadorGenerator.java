package database;

public class TestIdentificadorGenerator {

}